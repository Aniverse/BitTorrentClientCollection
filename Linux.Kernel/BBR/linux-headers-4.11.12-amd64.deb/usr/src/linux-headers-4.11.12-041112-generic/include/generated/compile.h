/* This file is auto generated, version 201707210350 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201707210350 SMP Fri Jul 21 07:53:15 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gomeisa"
#define LINUX_COMPILER "gcc version 6.3.0 20170618 (Ubuntu 6.3.0-19ubuntu1) "
