/* This file is auto generated, version 32-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#32-Ubuntu SMP Thu Jul 26 17:42:43 UTC 2018"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-amd64-060"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu 7.3.0-16ubuntu3)"
