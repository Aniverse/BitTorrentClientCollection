#define UTS_RELEASE "4.15.0-30-generic"
#define UTS_UBUNTU_RELEASE_ABI 30
